package com.digitalbd;

public class Functions {
	public String getLocalName() {
		return "";
	}
}
