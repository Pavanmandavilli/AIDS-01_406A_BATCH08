package com.digitalbd;

import java.util.HashMap;

public class Helper {
	public static String baseUrl = "http://localhost:8090/Train_Ticket_System/";
	public static String TestName="T ruon";
	public static String Currency = "RS";
	public static HashMap<String,String> TrainsCoach(){
		HashMap<String,String> coach = new HashMap<String,String>();
		coach.put("Economy", "Economy");
		coach.put("premium economy", "premium economy ");
		coach.put("business", "business");
		coach.put("first class", "first class");
		return coach;
	}
}
