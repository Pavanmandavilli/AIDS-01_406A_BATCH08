package com.digitalbd;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DbData;
/**
 * Servlet implementation class dashboard
 */
@WebServlet("/dashboard")
public class dashboard extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public dashboard() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  try {
			    String y=request.getParameter("email");
			    System.out.println(y);
		         Class.forName("com.mysql.jdbc.Driver");
		         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ticketing_system", "root", "");
		         Statement ps = con.createStatement();
		         ResultSet rs = ps.executeQuery("select * from payments where   email='"+y+"'");
		         List<DbData> x=new ArrayList<>();
		         while(rs.next())
		         {
		 
		        		 DbData x1=new DbData(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(8));
		        		 System.out.println("hiii");
		        		 x.add(x1);
		         }
		         request.setAttribute("y1", x);
		         System.out.println(request.getAttribute("y1"));
		         RequestDispatcher r=request.getRequestDispatcher("DataShow.jsp");
		        	r.forward(request, response);

		         
	   }
		  catch(Exception e)
		  {
			  
		  }

}
}