package TicketSystemInterface;

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Scalar.String;

public interface DatabaseModel {
	String tableName = null;
	/*Save all data*/
	public int Save();
	/*Update all Data*/
	public int Update();
	/*Delete Data*/
	public void Delete();
	/*Get Current Table Name*/
	java.lang.String GetTableName();
	default void SetById(int id) {};
}
